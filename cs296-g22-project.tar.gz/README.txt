Group 22

Members:

	Arpit Singh (120050037)

	Harish Koilada (120050038)

	Nishanth N Koushik (120050041)

We hereby state that all work that we are submitting for this assignment is our own work and we have not plagiarised it from anywhere.

Project - Escalator Simulation

Link to project webpage http://www.cse.iitb.ac.in/~rimcoharish/g22_project.html

References:

1. Design of Escalator 
   http://science.howstuffworks.com/transport/engines-equipment/escalator1.htm

2. Working of Escalator 
   http://vimeo.com/5196298

3. Box2d for Simulation 
   http://box2d.org/ 

4. Creating Converyor Belt 
   https://www.iforce2d.net/b2dtut/conveyor-belts/

5. Creating Revolute Joints 
   https://www.iforce2d.net/b2dtut/joints-revolute/