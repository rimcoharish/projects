#include <simplecpp>

struct rectangle{
	
	int number, color;
	bool check;                                                         // Members of the structure rectangle.
	Rectangle r1;
	Text t1;
	
	rectangle(int p,int q, bool r){                                     // Constructor 1.
		number=p;                                                       // Stores the value -1 if mine is present else 0 or the number of mines it touches.
		color=q;                                                        // White=0 Blue=1 Red=2
		check=r;                                                        // If opens if true.
		r1.reset(0,0,0,0);
	}
	
	rectangle(){                                                        // Constructor 2.
		number=-2;
		color=-2;
		check=true;
		r1.reset(0,0,0,0);
	}
    
	void bring_position_of_mines(int mines[], int number_of_mines, int rows, int columns){   // Generates position of mines and stores them in an array.
		int b=0;
		srand(time(NULL));
		for(int i=0; i<number_of_mines; i++) mines[i]=-1;
		while(true){
			bool found=false;
			int z=int(randuv(0.0, rows*columns-1));
			for(int i=0; i<number_of_mines;i++){
				if(mines[i]==z) {
					found=true;
					break;
				}
			}
			if(!found) {
				mines[b]=z;
				b++;
			}
			if ( b==number_of_mines) break;
		}
	}
	
	void update_mines_data(rectangle r[], int mines[], int number_of_mines){                   // Updates the data of rectangles with mines in it.
		for(int i=0; i<number_of_mines; i++) r[mines[i]]=rectangle(-1, 1, true);
	}
	
	void update_other_data(rectangle r[], int mines[], int number_of_mines, int rows, int columns){    // Updates the data of other rectangles.
		for(int i=0; i<rows*columns; i++) if(r[i].number!=-1) r[i]=rectangle(0, 1, true);
		for(int i=0; i<number_of_mines; i++){
			if((mines[i]/columns)-1>=0 && r[mines[i]-columns].number!=-1) r[mines[i]-columns].number+=1;
			if((mines[i]/columns)+1<=rows-1 && r[mines[i]+columns].number!=-1) r[mines[i]+columns].number+=1;
			if(mines[i]%columns!=0 && r[mines[i]-1].number!=-1) r[mines[i]-1].number+=1;
			if((mines[i]+1)%columns!=0 && r[mines[i]+1].number!=-1) r[mines[i]+1].number+=1;
			if((mines[i]/columns)-1>=0  && mines[i]%columns!=0 && r[mines[i]-columns-1].number!=-1) r[mines[i]-columns-1].number+=1;
			if((mines[i]/columns)-1>=0  && (mines[i]+1)%columns!=0 && r[mines[i]-columns+1].number!=-1) r[mines[i]-columns+1].number+=1;
			if((mines[i]/columns)+1<=rows-1 && mines[i]%columns!=0 && r[mines[i]+columns-1].number!=-1) r[mines[i]+columns-1].number+=1;
			if((mines[i]/columns)+1<=rows-1 && (mines[i]+1)%columns!=0 && r[mines[i]+columns+1].number!=-1)  r[mines[i]+columns+1].number+=1;
			
		}
	}
			
};

void open(rectangle r[], int indx, int mines[], int number_of_mines, int columns, int rows);
void expand(rectangle r[],int indx,int mines[],int number_of_mines,int columns,int rows);
void click(rectangle r[], int x, int y,int rows, int columns, int mines[], int number_of_mines);

void open(rectangle r[], int indx, int mines[], int number_of_mines, int columns, int rows){
	
	int rx=(indx%columns)*50+125, ry=(indx/columns)*50+125;
	
	if(r[indx].number==0 && r[indx].check){
		r[indx].r1.reset(rx,ry,50,50);
		r[indx].r1.setFill();
		r[indx].r1.setColor(COLOR("white"));
		r[indx].r1.imprint();
		r[indx].r1.reset(0,0,0,0);
		r[indx].color=0;
		r[indx].check=false;
		expand(r, indx,mines, number_of_mines,columns,rows);
	}
	
	else if(r[indx].number>0 && r[indx].check){
		r[indx].r1.reset(rx,ry,50,50);
		r[indx].r1.setFill();
		r[indx].r1.setColor(COLOR("white"));
		r[indx].r1.imprint();
		r[indx].r1.reset(0,0,0,0);
		r[indx].t1.reset(rx,ry,r[indx].number);
		r[indx].t1.imprint();
		r[indx].color=0;
		r[indx].check=false;
	}
	
	else if(r[indx].number==-1 && r[indx].check){
		beginFrame();
		Circle c[number_of_mines];
		for(int j=0; j<number_of_mines; j++) c[j].reset(0,0,0);
		endFrame();
		for(int i=0; i< number_of_mines; i++){
			rx=(mines[i]%columns)*50+125;
			ry=(mines[i]/columns)*50+125;
			r[mines[i]].r1.reset(rx,ry,50,50);
			r[mines[i]].r1.setFill();
			r[mines[i]].r1.setColor(COLOR("white"));
			r[mines[i]].r1.imprint();
			r[mines[i]].r1.reset(0,0,0,0);
			c[i].reset(rx,ry,15);
			c[i].setFill();	
			c[i].setColor(COLOR("black"));
			c[i].imprint();
			r[mines[i]].color=0;
			r[mines[i]].check=false;
		}
	}
}

void click(rectangle r[], int x, int y,int rows, int columns, int mines[], int number_of_mines, bool on[]){
	
	int indx=((x-100)/50)+(columns*((y-100)/50));
	int rx=(indx%columns)*50+125, ry=(indx/columns)*50+125;
	Circle radiob(0,0,0);
	
	if(x>100 && x<100+50*columns && y>100 && y<100+50*rows){
		
		if(!on[0] && !on[1]){
			open(r,indx,mines,number_of_mines,columns,rows);
		}
		
		if(on[0] && r[indx].color==1){
			
			r[indx].r1.reset(rx,ry,50,50);
			r[indx].r1.setFill();
			r[indx].r1.setColor(COLOR("red"));
			r[indx].r1.imprint();
			r[indx].r1.reset(0,0,0,0);
			r[indx].color=2;
		}
		
		if(on[1] && r[indx].color==2){
			r[indx].r1.reset(rx,ry,50,50);
			r[indx].r1.setFill();
			r[indx].r1.setColor(COLOR("blue"));
			r[indx].r1.imprint();
			r[indx].r1.reset(0,0,0,0);
			r[indx].color=1;
		}
	}
	
	if(x>(200+50*columns) && x<(300+50*columns) && y>100 && y<150){
		beginFrame();
		if(on[1]){
			on[1]=false;
			radiob.reset(180+(50*columns),225,7);
			radiob.setFill(true);
			radiob.setColor(COLOR("white"));
			radiob.imprint();
			on[0]=true;
			radiob.reset(180+(50*columns),125,7);
			radiob.setFill(true);
			radiob.setColor(COLOR("black"));
			radiob.imprint();
		}
		else if(on[0]){
			on[0]=false;
			radiob.reset(180+(50*columns),125,7);
			radiob.setFill(true);
			radiob.setColor(COLOR("white"));
			radiob.imprint();
		}
		else{
			on[0]=true;
			radiob.reset(180+(50*columns),125,7);
			radiob.setFill(true);
			radiob.setColor(COLOR("black"));
			radiob.imprint();
		}
		endFrame();
	}
	
	if(x>(200+50*columns) && x<(300+50*columns) && y>200 && y<250){
		beginFrame();
		if(on[0]){
			on[0]=false;
			radiob.reset(180+(50*columns),125,7);
			radiob.setFill(true);
			radiob.setColor(COLOR("white"));
			radiob.imprint();
			on[1]=true;
			radiob.reset(180+(50*columns),225,7);
			radiob.setFill(true);
			radiob.setColor(COLOR("black"));
			radiob.imprint();
		}
		else if(on[1]){
			on[1]=false;
			radiob.reset(180+(50*columns),225,7);
			radiob.setFill(true);
			radiob.setColor(COLOR("white"));
			radiob.imprint();
		}
		else{
			on[1]=true;
			radiob.reset(180+(50*columns),225,7);
			radiob.setFill(true);
			radiob.setColor(COLOR("black"));
			radiob.imprint();
		}
		endFrame();
	};
		
}

void expand(rectangle r[],int indx,int mines[],int number_of_mines,int columns,int rows){
	if(indx-columns>=0) open(r, indx-columns, mines, number_of_mines, columns, rows);
	if(indx+columns<=rows*columns-1) open(r, indx+columns, mines, number_of_mines, columns, rows);
	if(indx%columns!=0) open(r, indx-1, mines, number_of_mines, columns, rows);
	if((indx+1)%columns!=0) open(r, indx+1, mines, number_of_mines, columns, rows);
	if((indx-columns>=0) && (indx%columns!=0)) open(r, indx-columns-1, mines, number_of_mines, columns, rows);
	if((indx-columns>=0) && ((indx+1)%columns!=0)) open(r, indx-columns+1, mines, number_of_mines, columns, rows);
	if((indx+columns<=rows*columns-1) && (indx%columns!=0)) open(r, indx+columns-1, mines, number_of_mines, columns, rows);
	if((indx+columns<=rows*columns-1) && ((indx+1)%columns!=0)) open(r, indx+columns+1, mines, number_of_mines, columns, rows);
}

main_program{
	
	int rows, columns, number_of_mines;
	initCanvas("MINESWEEPER", 550,550);
	Rectangle rstart[4];
	for(int i=0; i<2; i++) for(int j=0; j<2; j++){
		rstart[i+j].reset(150+250*i,150+250*j,200,200);
		rstart[i+j].imprint();
	}
	Text tstart[7];
	tstart[0].reset(150,100,"6x6");
	tstart[1].reset(150,200,"8 mines");
	tstart[2].reset(400,100,"8x8");
	tstart[3].reset(400,200,"10 mines");
	tstart[4].reset(150,350,"10x10");
	tstart[5].reset(150,450,"15 mines");
	tstart[6].reset(400,400,"Custom");
	
	bool custom=false;
	
	while(true){
		int clck=getClick();
		int x=clck/65536;
		int y=clck%65536;
		if(x>50 && x<250 && y>50 && y<250){
			rows=6;
			columns=6;
			number_of_mines=8;
			break;
		}
		else if(x>300 && x<500 && y>50 && y<250){
			rows=8;
			columns=8;
			number_of_mines=10;
			break;
		}
		else if(x>50 && x<250 && y>300 && y<500){
			rows=10;
			columns=10;
			number_of_mines=15;
			break;
		}
		else if(x>300 && x<500 && y>300 && y<500){
			custom=true;
			break;
		}
	}
	
	closeCanvas();
	
	if(custom){
		cout << "The number of rows: ";
		cin >> rows;
		cout << "The number of columns: ";
		cin >> columns;
		cout << "The number of mines: ";
		cin >> number_of_mines;
	}
	
	int mines[number_of_mines];		
	bool on[2];
	on[1]=false;
	on[0]=false;	
	
	initCanvas("MINESWEEPER", 400+(50*columns), 200+(50*rows));
	rectangle r[rows*columns];
	beginFrame();
	for(int i=0; i<columns; i++){
	    for(int j=0; j<rows; j++){
	        r[i+columns*j].r1.reset(125+50*i,125+50*j,50,50);
	        r[i+columns*j].r1.setFill();
	        r[i+columns*j].r1.setColor(COLOR("blue"));
	        r[i+columns*j].r1.imprint();
	        r[i+columns*j].r1.reset(0,0,0,0);
		}
	}
	Line l[rows+columns+2];
	for(int i=0; i<columns+1; i++){
		l[i].reset(100+i*50,100,100+i*50,100+rows*50);
		l[i].imprint();
	}
	for(int i=0; i<rows+1; i++){
		l[i+columns+1].reset(100,100+i*50,100+columns*50,100+i*50);
		l[i+columns+1].imprint();
	}
	endFrame();
	Rectangle ressen(0,0,50,50);
	ressen.setFill(false);
	ressen.setColor(COLOR("white"));
	Rectangle rflag(250+(50*columns),125,100,50);
	rflag.imprint();
	rflag.reset(0,0,0,0);
	Circle cflag(180+(50*columns),125,10);
	cflag.imprint();
	Rectangle runflag(250+(50*columns),225,100,50);
	runflag.imprint();
	Circle cunflag(180+(50*columns),225,10);
	cunflag.imprint();
	runflag.reset(0,0,0,0);
	Text t1(250+(50*columns),125,"FLAG");
	Text t2(250+(50*columns),225,"UNFLAG");
	
	r[0].bring_position_of_mines(mines,number_of_mines,rows,columns);
	r[0].update_mines_data(r,mines,number_of_mines);
	r[0].update_other_data(r,mines,number_of_mines,rows,columns);
	
	Text cmd(200+25*columns,50,"GAME START");
	wait(2);
	cmd.hide();
	
	while(true){
		int clickPos=getClick();
		int x=clickPos/65536;
		int y=clickPos%65536;
		click(r,x,y,rows,columns,mines,number_of_mines,on);
		if(!r[mines[0]].check){
			custom=false;
			break;
		}
		for(int i=0; i<rows*columns; i++){
			if(r[i].number!=-1 && !r[i].check) custom=true;
			else if(r[i].number!=-1 && r[i].check){
				custom=false;
				break;
			}
		}
		if(custom) break;
	}
	if(custom){
		Text result(200+25*columns,50,"YOU WIN");
		result.imprint();
	}
	else{
		Text result(200+25*columns,50,"GAME OVER");
		result.imprint();
	}
	getClick();
}
